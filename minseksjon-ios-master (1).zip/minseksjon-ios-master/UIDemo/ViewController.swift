//
//  ViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 26/03/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

