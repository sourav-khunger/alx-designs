//
//  RegisterViewController.swift
//  UIDemo
//
//  Created by Siddhant Jain on 27/03/19.
//  Copyright © 2019 Siddhant. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {

    var attrs = [
        NSAttributedString.Key.font : UIFont(name: "OpenSans-Regular", size: 16.0) ?? UIFont.systemFont(ofSize: 16.0),
        NSAttributedString.Key.foregroundColor : UIColor.white,
        NSAttributedString.Key.underlineStyle : 1] as [NSAttributedString.Key : Any]

    var attributedString = NSMutableAttributedString(string:"")
    
    @IBOutlet weak var loginButton: UIButton!
    @IBAction func registerTapped(_ sender: Any) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "GetStartedViewController") else { return }
        self.navigationController?.pushViewController(vc, animated: true)
    }


    @IBAction func loginTapped(_ sender: Any) {
        if navigationController?.viewControllers.last is LoginViewController { self.navigationController?.popViewController(animated: true)
        } else {
            guard let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") else { return }
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let buttonTitleStr = NSMutableAttributedString(string:"Logg inn", attributes:attrs)
        attributedString.append(buttonTitleStr)
        loginButton.setAttributedTitle(attributedString, for: .normal)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
